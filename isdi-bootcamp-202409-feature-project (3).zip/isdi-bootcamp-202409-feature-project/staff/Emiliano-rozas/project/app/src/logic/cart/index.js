import updateCart from './updateCart'
import getCart from './getCart'
// import addTocart from './addToCart'
// import removeAllFromCart from './removeAllFromCart'
// import updateQuantity from './updateQuantity'

export {
    updateCart,
    getCart,
    // addTocart,
    // removeAllFromCart,
    // updateQuantity,
}