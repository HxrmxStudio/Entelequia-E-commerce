import getProducts from './getProducts'

export {
    getProducts
}