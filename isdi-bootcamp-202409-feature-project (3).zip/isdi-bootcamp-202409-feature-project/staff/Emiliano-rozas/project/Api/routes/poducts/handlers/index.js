import getProductsHandler from './getProductsHandler.js'

export {
    getProductsHandler
}