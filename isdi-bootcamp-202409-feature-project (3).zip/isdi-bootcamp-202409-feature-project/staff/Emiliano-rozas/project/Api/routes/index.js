import usersRouter from './users/index.js'
import productsRouter from './poducts/index.js'
import cartRouter from './cart/index.js'
import orderRouter from './order/index.js'
import paymentsRouter from './payments/index.js'

export {
    usersRouter,
    productsRouter,
    cartRouter,
    orderRouter,
    paymentsRouter
}