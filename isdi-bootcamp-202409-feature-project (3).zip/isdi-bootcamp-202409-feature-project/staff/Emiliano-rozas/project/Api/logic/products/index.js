import getProducts from './getProducts.js'

export {
    getProducts,
}