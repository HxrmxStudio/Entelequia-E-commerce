import processPayment from './processPayment.js'

export {
    processPayment,
}