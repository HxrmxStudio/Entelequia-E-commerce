curl -H 'Content-Type: application/json' http://localhost:7000/products -v
