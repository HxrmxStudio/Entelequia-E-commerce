curl -H 'Content-Type: application/json' -d '{
  "name": "Ikari Kun",
  "email": "ikari@kun.com",
  "username": "ikarikun",
  "password": "123123123",
  "password-repeat": "123123123"
}' http://localhost:7000/users -v
