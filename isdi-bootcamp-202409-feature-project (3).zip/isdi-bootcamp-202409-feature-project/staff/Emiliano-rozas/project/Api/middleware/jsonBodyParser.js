import { json } from 'express'

export default json()